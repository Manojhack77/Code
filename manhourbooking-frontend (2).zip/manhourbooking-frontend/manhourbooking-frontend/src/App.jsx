import Staff from "./pages/staff";

function App() {
  return <Staff></Staff>
}

export default App;