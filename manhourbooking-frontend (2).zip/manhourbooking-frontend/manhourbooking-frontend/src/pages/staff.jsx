import { useState } from "react";

function Staff() {
  const [workingHours, setWorkingHours] = useState("");
  const [editingId, setEditingId] = useState(null);
  const [message, setMessage] = useState("");

  // Temporary data for frontend development
  const staffId = "ST1025";

  const currentDate = new Date();

  const currentMonth = currentDate.toLocaleString("default", {
    month: "long",
  });

  const currentYear = currentDate.getFullYear();

  // Temporary booking history
  const [bookingHistory, setBookingHistory] = useState([
    {
      id: 1,
      month: "August",
      year: 2026,
      hours: 160,
    },
    {
      id: 2,
      month: "July",
      year: 2026,
      hours: 155,
    },
    {
      id: 3,
      month: "June",
      year: 2026,
      hours: 150,
    },
  ]);

  const handleSubmit = (e) => {
    e.preventDefault();

    if (workingHours === "") {
      setMessage("Please enter your working hours.");
      return;
    }

    const hours = Number(workingHours);

    if (hours < 0) {
      setMessage("Working hours cannot be negative.");
      return;
    }

    if (editingId !== null) {
      // Update existing booking
      setBookingHistory((previous) =>
        previous.map((booking) =>
          booking.id === editingId
            ? { ...booking, hours: hours }
            : booking
        )
      );

      setMessage("Booking updated successfully.");
      setEditingId(null);
    } else {
      // Add new booking
      setBookingHistory((previous) => [
        {
          id: Date.now(),
          month: currentMonth,
          year: currentYear,
          hours: hours,
        },
        ...previous,
      ]);

      setMessage("Working hours submitted successfully.");
    }

    setWorkingHours("");
  };

  const handleEdit = (booking) => {
    setWorkingHours(booking.hours);
    setEditingId(booking.id);
    setMessage("");
  };

  const handleCancelEdit = () => {
    setWorkingHours("");
    setEditingId(null);
    setMessage("");
  };

  return (
    <div className="min-h-screen bg-slate-50">

      {/* Header */}
      <header className="border-b border-slate-200 bg-white">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">

          <div className="text-right">
            <p className="text-xs text-slate-500">
              Staff ID
            </p>

            <p className="font-medium text-slate-800">
              {staffId}
            </p>
          </div>

        </div>
      </header>

      {/* Main Content */}
      <main className="mx-auto max-w-6xl px-6 py-8">

        {/* Current Month */}
        <div className="mb-6">
          <h2 className="text-2xl font-semibold text-slate-800">
            Monthly Hours
          </h2>

          <p className="mt-1 text-sm text-slate-500">
            Enter your working hours for the current month.
          </p>
        </div>

        {/* Booking Form */}
        <div className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm">

          <div className="grid gap-5 sm:grid-cols-2">

            {/* Month */}
            <div>
              <label className="mb-2 block text-sm font-medium text-slate-700">
                Month
              </label>

              <input
                type="text"
                value={currentMonth}
                readOnly
                className="w-full rounded-lg border border-slate-200 bg-slate-50 px-4 py-2.5 text-slate-700 outline-none"
              />
            </div>

            {/* Year */}
            <div>
              <label className="mb-2 block text-sm font-medium text-slate-700">
                Year
              </label>

              <input
                type="text"
                value={currentYear}
                readOnly
                className="w-full rounded-lg border border-slate-200 bg-slate-50 px-4 py-2.5 text-slate-700 outline-none"
              />
            </div>

          </div>

          {/* Working Hours */}
          <div className="mt-5">

            <label className="mb-2 block text-sm font-medium text-slate-700">
              Working Hours
            </label>

            <input
              type="number"
              min="0"
              value={workingHours}
              onChange={(e) => {
                setWorkingHours(e.target.value);
                setMessage("");
              }}
              placeholder="Enter working hours"
              className="w-full rounded-lg border border-slate-300 px-4 py-2.5 text-slate-800 outline-none transition focus:border-blue-500 focus:ring-2 focus:ring-blue-100"
            />

          </div>

          {/* Message */}
          {message && (
            <p
              className={`mt-3 text-sm ${
                message.includes("successfully")
                  ? "text-emerald-600"
                  : "text-red-600"
              }`}
            >
              {message}
            </p>
          )}

          {/* Buttons */}
          <div className="mt-6 flex gap-3">

            <button
              onClick={handleSubmit}
              className="rounded-lg bg-blue-600 px-5 py-2.5 text-sm font-medium text-white transition hover:bg-blue-700"
            >
              {editingId !== null ? "Update Hours" : "Submit Hours"}
            </button>

            {editingId !== null && (
              <button
                onClick={handleCancelEdit}
                className="rounded-lg border border-slate-300 px-5 py-2.5 text-sm font-medium text-slate-700 transition hover:bg-slate-50"
              >
                Cancel
              </button>
            )}

          </div>
        </div>

        {/* Booking History */}
        <div className="mt-8">

          <div className="mb-4">
            <h2 className="text-xl font-semibold text-slate-800">
              Booking History
            </h2>

            <p className="mt-1 text-sm text-slate-500">
              View and modify your previously submitted hours.
            </p>
          </div>

          <div className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">

            <div className="overflow-x-auto">

              <table className="w-full text-left text-sm">

                <thead className="border-b border-slate-200 bg-slate-50">
                  <tr>
                    <th className="px-6 py-4 font-medium text-slate-600">
                      Month
                    </th>

                    <th className="px-6 py-4 font-medium text-slate-600">
                      Year
                    </th>

                    <th className="px-6 py-4 font-medium text-slate-600">
                      Hours Booked
                    </th>

                    <th className="px-6 py-4 text-right font-medium text-slate-600">
                      Action
                    </th>
                  </tr>
                </thead>

                <tbody className="divide-y divide-slate-100">

                  {bookingHistory.map((booking) => (
                    <tr
                      key={booking.id}
                      className="transition hover:bg-slate-50"
                    >

                      <td className="px-6 py-4 text-slate-700">
                        {booking.month}
                      </td>

                      <td className="px-6 py-4 text-slate-700">
                        {booking.year}
                      </td>

                      <td className="px-6 py-4 font-medium text-slate-800">
                        {booking.hours}
                      </td>

                      <td className="px-6 py-4 text-right">

                        <button
                          onClick={() => handleEdit(booking)}
                          className="font-medium text-blue-600 hover:text-blue-800"
                        >
                          Edit
                        </button>

                      </td>

                    </tr>
                  ))}

                </tbody>

              </table>

            </div>

          </div>
        </div>

      </main>
    </div>
  );
}

export default Staff;