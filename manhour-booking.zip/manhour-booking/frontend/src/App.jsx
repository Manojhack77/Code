import { Navigate, Route, Routes } from 'react-router-dom';
import { useAuth } from './AuthContext.jsx';
import Login from './pages/Login.jsx';
import Register from './pages/Register.jsx';
import StaffDashboard from './pages/StaffDashboard.jsx';
import AdminDashboard from './pages/AdminDashboard.jsx';
import Layout from './components/Layout.jsx';

const home = (user) => (!user ? '/login' : user.role === 'ADMIN' ? '/admin' : '/staff');

function Protected({ role, children }) {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  if (user.role !== role) return <Navigate to={home(user)} replace />;
  return <Layout>{children}</Layout>;
}

function GuestOnly({ children }) {
  const { user } = useAuth();
  return user ? <Navigate to={home(user)} replace /> : children;
}

export default function App() {
  const { user } = useAuth();
  return (
    <Routes>
      <Route path="/login" element={<GuestOnly><Login /></GuestOnly>} />
      <Route path="/register" element={<GuestOnly><Register /></GuestOnly>} />
      <Route path="/staff" element={<Protected role="STAFF"><StaffDashboard /></Protected>} />
      <Route path="/admin" element={<Protected role="ADMIN"><AdminDashboard /></Protected>} />
      <Route path="*" element={<Navigate to={home(user)} replace />} />
    </Routes>
  );
}
