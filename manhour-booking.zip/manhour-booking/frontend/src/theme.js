import { createTheme } from '@mui/material/styles';

export default createTheme({
  palette: {
    primary: { main: '#1B4B5A' },
    secondary: { main: '#5C6B73' },
    background: { default: '#F2F5F5', paper: '#FFFFFF' },
    text: { primary: '#1D2A30', secondary: '#55646B' },
  },
  shape: { borderRadius: 6 },
  typography: {
    fontFamily: '"IBM Plex Sans", system-ui, -apple-system, "Segoe UI", sans-serif',
    h5: { fontWeight: 600 },
    h6: { fontWeight: 600 },
    button: { textTransform: 'none', fontWeight: 500 },
  },
  components: {
    MuiTableCell: { styleOverrides: { head: { fontWeight: 600, backgroundColor: '#E6ECEE' } } },
    MuiPaper: { defaultProps: { elevation: 0 }, styleOverrides: { root: { border: '1px solid #D5DEE1' } } },
  },
});
