import { useCallback, useEffect, useState } from 'react';
import {
  Box, Button, Chip, MenuItem, Paper, Stack, Table, TableBody, TableCell, TableContainer,
  TableHead, TableRow, TextField, Typography,
} from '@mui/material';
import api, { errMsg } from '../api';
import Notice from '../components/Notice.jsx';
import { MONTHS, hoursFmt, money } from '../util.js';

export default function StaffDashboard() {
  const now = new Date();
  const [month, setMonth] = useState(now.getMonth() + 1);
  const [year, setYear] = useState(now.getFullYear());
  const [projects, setProjects] = useState([]);
  const [history, setHistory] = useState([]);
  const [hours, setHours] = useState({});
  const [notice, setNotice] = useState(null);
  const [busy, setBusy] = useState('');

  const load = useCallback(async () => {
    const [p, h] = await Promise.all([api.get('/staff/projects'), api.get('/staff/bookings')]);
    setProjects(p.data);
    setHistory(h.data);
  }, []);

  useEffect(() => {
    load().catch((e) => setNotice({ severity: 'error', text: errMsg(e) }));
  }, [load]);

  const existing = (wbs) => history.find((b) => b.wbsCode === wbs && b.month === month && b.year === year);
  const valueFor = (p) => hours[p.wbsCode] ?? String(p.suggestedHours);
  const estimate = (p) => (Number(valueFor(p)) || 0) * Number(p.baseRate);

  const submit = async (p) => {
    setBusy(p.wbsCode);
    try {
      await api.post('/staff/bookings', {
        wbsCode: p.wbsCode, hoursBooked: Number(valueFor(p)), month, year,
      });
      await load();
      setNotice({ severity: 'success', text: `Submitted ${hoursFmt(valueFor(p))} hours on ${p.wbsCode} for ${MONTHS[month - 1]} ${year}.` });
    } catch (e) {
      setNotice({ severity: 'error', text: errMsg(e) });
    } finally {
      setBusy('');
    }
  };

  return (
    <Stack spacing={4}>
      <Box>
        <Typography variant="h5" gutterBottom>Log monthly hours</Typography>
        <Stack direction="row" spacing={2} sx={{ mb: 2 }}>
          <TextField select size="small" label="Month" value={month} onChange={(e) => setMonth(Number(e.target.value))} sx={{ minWidth: 160 }}>
            {MONTHS.map((m, i) => <MenuItem key={m} value={i + 1}>{m}</MenuItem>)}
          </TextField>
          <TextField size="small" label="Year" type="number" value={year} onChange={(e) => setYear(Number(e.target.value))} sx={{ width: 110 }} />
        </Stack>

        <TableContainer component={Paper}>
          <Table size="small">
            <TableHead>
              <TableRow>
                <TableCell>WBS code</TableCell>
                <TableCell>Project</TableCell>
                <TableCell align="right">Allocation</TableCell>
                <TableCell>Expires</TableCell>
                <TableCell align="right" sx={{ width: 140 }}>Hours</TableCell>
                <TableCell align="right">Estimated cost</TableCell>
                <TableCell align="right" />
              </TableRow>
            </TableHead>
            <TableBody>
              {projects.length === 0 && (
                <TableRow><TableCell colSpan={7}>No projects assigned yet. Ask an administrator to add you to a project.</TableCell></TableRow>
              )}
              {projects.map((p) => {
                const done = existing(p.wbsCode);
                return (
                  <TableRow key={p.wbsCode}>
                    <TableCell>{p.wbsCode}</TableCell>
                    <TableCell>{p.projectName}</TableCell>
                    <TableCell align="right">{hoursFmt(p.allocationPercentage)}%</TableCell>
                    <TableCell>
                      {p.expiryDate} {p.expired && <Chip size="small" color="error" label="Expired" sx={{ ml: 1 }} />}
                    </TableCell>
                    <TableCell align="right">
                      {done ? hoursFmt(done.hoursBooked) : (
                        <TextField size="small" type="number" value={valueFor(p)}
                          onChange={(e) => setHours({ ...hours, [p.wbsCode]: e.target.value })}
                          inputProps={{ min: 0, step: 0.25 }} disabled={p.expired} />
                      )}
                    </TableCell>
                    <TableCell align="right">{money(done ? done.calculatedCost : estimate(p))}</TableCell>
                    <TableCell align="right">
                      {done ? <Chip size="small" color="success" label="Submitted" /> : (
                        <Button size="small" variant="contained" disabled={p.expired || busy === p.wbsCode || !(Number(valueFor(p)) > 0)}
                          onClick={() => submit(p)}>Submit hours</Button>
                      )}
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </TableContainer>
        <Typography variant="caption" color="text.secondary" sx={{ mt: 1, display: 'block' }}>
          Hours start at your allocation share of the standard month. Change them if you worked more or less.
        </Typography>
      </Box>

      <Box>
        <Typography variant="h6" gutterBottom>My booking history</Typography>
        <TableContainer component={Paper}>
          <Table size="small">
            <TableHead>
              <TableRow>
                <TableCell>Period</TableCell>
                <TableCell>WBS code</TableCell>
                <TableCell>Project</TableCell>
                <TableCell align="right">Hours</TableCell>
                <TableCell align="right">Cost</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {history.length === 0 && <TableRow><TableCell colSpan={5}>You haven't submitted any hours yet.</TableCell></TableRow>}
              {history.map((b) => (
                <TableRow key={b.bookingId}>
                  <TableCell>{MONTHS[b.month - 1]} {b.year}</TableCell>
                  <TableCell>{b.wbsCode}</TableCell>
                  <TableCell>{b.projectName}</TableCell>
                  <TableCell align="right">{hoursFmt(b.hoursBooked)}</TableCell>
                  <TableCell align="right">{money(b.calculatedCost)}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </Box>
      <Notice notice={notice} onClose={() => setNotice(null)} />
    </Stack>
  );
}
