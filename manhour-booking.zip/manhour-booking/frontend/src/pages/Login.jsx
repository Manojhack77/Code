import { useState } from 'react';
import { Alert, Button, Link, Stack, TextField, Typography } from '@mui/material';
import { Link as RouterLink, useNavigate } from 'react-router-dom';
import AuthShell from '../components/AuthShell.jsx';
import { useAuth } from '../AuthContext.jsx';
import { errMsg } from '../api';

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ username: '', password: '' });
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    setBusy(true);
    try {
      const u = await login(form.username, form.password);
      navigate(u.role === 'ADMIN' ? '/admin' : '/staff', { replace: true });
    } catch (err) {
      setError(errMsg(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <AuthShell title="Login">
      <form onSubmit={submit}>
        <Stack spacing={2.5}>
          {error && <Alert severity="error">{error}</Alert>}
          <TextField label="Username" value={form.username} onChange={set('username')} autoFocus required fullWidth />
          <TextField label="Password" type="password" value={form.password} onChange={set('password')} required fullWidth />
          <Button type="submit" variant="contained" size="large" disabled={busy}>Sign in</Button>
          <Typography variant="body2" align="center">
            Don't have an account? <Link component={RouterLink} to="/register">Sign up</Link>
          </Typography>
        </Stack>
      </form>
    </AuthShell>
  );
}
