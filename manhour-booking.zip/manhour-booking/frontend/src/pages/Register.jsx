import { useState } from 'react';
import { Alert, Button, Link, MenuItem, Stack, TextField, Typography } from '@mui/material';
import { Link as RouterLink, useNavigate } from 'react-router-dom';
import AuthShell from '../components/AuthShell.jsx';
import { useAuth } from '../AuthContext.jsx';
import { errMsg } from '../api';

export default function Register() {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ fullName: '', username: '', password: '', role: 'staff' });
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    setBusy(true);
    try {
      const u = await register(form);
      navigate(u.role === 'ADMIN' ? '/admin' : '/staff', { replace: true });
    } catch (err) {
      setError(errMsg(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <AuthShell title="Create your account">
      <form onSubmit={submit}>
        <Stack spacing={2.5}>
          {error && <Alert severity="error">{error}</Alert>}
          <TextField label="Full name" helperText="e.g. John Doe" value={form.fullName} onChange={set('fullName')} required fullWidth autoFocus />
          <TextField label="Username" helperText="e.g. johndoe123" value={form.username} onChange={set('username')} required fullWidth />
          <TextField label="Password" type="password" helperText="At least 6 characters" value={form.password} onChange={set('password')} required fullWidth />
          <TextField select label="Account role" value={form.role} onChange={set('role')} fullWidth>
            <MenuItem value="staff">Staff</MenuItem>
            <MenuItem value="admin">Admin</MenuItem>
          </TextField>
          <Button type="submit" variant="contained" size="large" disabled={busy}>Register</Button>
          <Typography variant="body2" align="center">
            Already have an account? <Link component={RouterLink} to="/login">Login</Link>
          </Typography>
        </Stack>
      </form>
    </AuthShell>
  );
}
