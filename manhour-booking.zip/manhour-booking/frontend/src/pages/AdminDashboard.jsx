import { useState } from 'react';
import { Box, Tab, Tabs, Typography } from '@mui/material';
import BookingsTab from '../components/admin/BookingsTab.jsx';
import ProjectsTab from '../components/admin/ProjectsTab.jsx';
import MappingsTab from '../components/admin/MappingsTab.jsx';

export default function AdminDashboard() {
  const [tab, setTab] = useState(0);
  return (
    <Box>
      <Typography variant="h5" gutterBottom>Administration</Typography>
      <Tabs value={tab} onChange={(_, v) => setTab(v)} sx={{ mb: 3, borderBottom: 1, borderColor: 'divider' }}>
        <Tab label="Bookings" />
        <Tab label="Projects" />
        <Tab label="Staff and mapping" />
      </Tabs>
      {tab === 0 && <BookingsTab />}
      {tab === 1 && <ProjectsTab />}
      {tab === 2 && <MappingsTab />}
    </Box>
  );
}
