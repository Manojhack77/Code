import { createContext, useCallback, useContext, useMemo, useState } from 'react';
import api from './api';

const AuthContext = createContext(null);

const stored = () => {
  try {
    return JSON.parse(localStorage.getItem('mhb_user'));
  } catch {
    return null;
  }
};

export function AuthProvider({ children }) {
  const [user, setUser] = useState(stored);

  const save = useCallback((data) => {
    localStorage.setItem('mhb_token', data.token);
    const u = { memberId: data.memberId, name: data.name, username: data.username, role: data.role };
    localStorage.setItem('mhb_user', JSON.stringify(u));
    setUser(u);
    return u;
  }, []);

  const login = useCallback(async (username, password) => {
    const { data } = await api.post('/auth/login', { username, password });
    return save(data);
  }, [save]);

  const register = useCallback(async (payload) => {
    const { data } = await api.post('/auth/register', payload);
    return save(data);
  }, [save]);

  const logout = useCallback(() => {
    localStorage.removeItem('mhb_token');
    localStorage.removeItem('mhb_user');
    setUser(null);
  }, []);

  const value = useMemo(() => ({ user, login, register, logout }), [user, login, register, logout]);
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export const useAuth = () => useContext(AuthContext);
