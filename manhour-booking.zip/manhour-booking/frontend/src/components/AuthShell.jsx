import { Box, Paper, Typography } from '@mui/material';

export default function AuthShell({ title, children }) {
  return (
    <Box sx={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', p: 2 }}>
      <Paper sx={{ p: 4, width: '100%', maxWidth: 440 }}>
        <Typography variant="overline" color="text.secondary">ManHourBooking</Typography>
        <Typography variant="h5" sx={{ mb: 3 }}>{title}</Typography>
        {children}
      </Paper>
    </Box>
  );
}
