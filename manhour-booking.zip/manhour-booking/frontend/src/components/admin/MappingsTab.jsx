import { useCallback, useEffect, useState } from 'react';
import {
  Box, Button, MenuItem, Paper, Stack, Table, TableBody, TableCell, TableContainer, TableHead,
  TableRow, TextField, Typography,
} from '@mui/material';
import api, { errMsg } from '../../api';
import Notice from '../Notice.jsx';
import { hoursFmt } from '../../util.js';

export default function MappingsTab() {
  const [projects, setProjects] = useState([]);
  const [staff, setStaff] = useState([]);
  const [mappings, setMappings] = useState([]);
  const [form, setForm] = useState({ wbsCode: '', memberId: '', allocationPercentage: '' });
  const [rates, setRates] = useState({});
  const [notice, setNotice] = useState(null);

  const load = useCallback(async () => {
    try {
      const [p, s, m] = await Promise.all([
        api.get('/admin/projects'), api.get('/admin/staff'), api.get('/admin/mappings'),
      ]);
      setProjects(p.data);
      setStaff(s.data);
      setMappings(m.data);
    } catch (e) {
      setNotice({ severity: 'error', text: errMsg(e) });
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });
  const staffOnly = staff.filter((s) => s.role === 'STAFF');

  const saveMapping = async () => {
    try {
      await api.post('/admin/mappings', { ...form, allocationPercentage: Number(form.allocationPercentage) });
      setForm({ ...form, allocationPercentage: '' });
      setNotice({ severity: 'success', text: 'Mapping saved.' });
      load();
    } catch (e) {
      setNotice({ severity: 'error', text: errMsg(e) });
    }
  };

  const removeMapping = async (id) => {
    try {
      await api.delete(`/admin/mappings/${id}`);
      setNotice({ severity: 'success', text: 'Mapping removed.' });
      load();
    } catch (e) {
      setNotice({ severity: 'error', text: errMsg(e) });
    }
  };

  const saveRate = async (s) => {
    try {
      await api.put(`/admin/staff/${s.memberId}/rate`, { baseRate: Number(rates[s.memberId]) });
      setRates({ ...rates, [s.memberId]: undefined });
      setNotice({ severity: 'success', text: `Base rate updated for ${s.name}.` });
      load();
    } catch (e) {
      setNotice({ severity: 'error', text: errMsg(e) });
    }
  };

  const formValid = form.wbsCode && form.memberId && Number(form.allocationPercentage) > 0;

  return (
    <Stack spacing={4}>
      <Box>
        <Typography variant="h6" gutterBottom>Assign staff to a project</Typography>
        <Stack direction={{ xs: 'column', md: 'row' }} spacing={2} sx={{ mb: 2 }}>
          <TextField select size="small" label="Project" value={form.wbsCode} onChange={set('wbsCode')} sx={{ minWidth: 240 }}>
            {projects.map((p) => <MenuItem key={p.wbsCode} value={p.wbsCode}>{p.wbsCode} - {p.projectName}</MenuItem>)}
          </TextField>
          <TextField select size="small" label="Staff member" value={form.memberId} onChange={set('memberId')} sx={{ minWidth: 220 }}>
            {staffOnly.map((s) => <MenuItem key={s.memberId} value={s.memberId}>{s.name}</MenuItem>)}
          </TextField>
          <TextField size="small" label="Allocation (%)" type="number" value={form.allocationPercentage} onChange={set('allocationPercentage')}
            inputProps={{ min: 0, max: 100, step: 0.5 }} sx={{ width: 150 }} />
          <Button variant="contained" onClick={saveMapping} disabled={!formValid}>Save mapping</Button>
        </Stack>
        <Typography variant="caption" color="text.secondary">
          Saving again for the same project and person updates the percentage. A person's total across projects cannot pass 100%.
        </Typography>

        <TableContainer component={Paper} sx={{ mt: 2 }}>
          <Table size="small">
            <TableHead>
              <TableRow>
                <TableCell>WBS code</TableCell>
                <TableCell>Project</TableCell>
                <TableCell>Staff member</TableCell>
                <TableCell align="right">Allocation</TableCell>
                <TableCell />
              </TableRow>
            </TableHead>
            <TableBody>
              {mappings.length === 0 && <TableRow><TableCell colSpan={5}>No one is assigned to a project yet.</TableCell></TableRow>}
              {mappings.map((m) => (
                <TableRow key={m.mappingId} hover>
                  <TableCell>{m.wbsCode}</TableCell>
                  <TableCell>{m.projectName}</TableCell>
                  <TableCell>{m.staffName}</TableCell>
                  <TableCell align="right">{hoursFmt(m.allocationPercentage)}%</TableCell>
                  <TableCell align="right"><Button size="small" color="error" onClick={() => removeMapping(m.mappingId)}>Remove</Button></TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </Box>

      <Box>
        <Typography variant="h6" gutterBottom>Staff base rates</Typography>
        <TableContainer component={Paper}>
          <Table size="small">
            <TableHead>
              <TableRow>
                <TableCell>Member ID</TableCell>
                <TableCell>Name</TableCell>
                <TableCell>Role</TableCell>
                <TableCell align="right">Base rate per hour</TableCell>
                <TableCell />
              </TableRow>
            </TableHead>
            <TableBody>
              {staff.map((s) => (
                <TableRow key={s.memberId}>
                  <TableCell>{s.memberId}</TableCell>
                  <TableCell>{s.name}</TableCell>
                  <TableCell>{s.role === 'ADMIN' ? 'Administrator' : 'Staff'}</TableCell>
                  <TableCell align="right">
                    <TextField size="small" type="number" sx={{ width: 130 }}
                      value={rates[s.memberId] ?? String(s.baseRate)}
                      onChange={(e) => setRates({ ...rates, [s.memberId]: e.target.value })}
                      inputProps={{ min: 0, step: 0.01 }} />
                  </TableCell>
                  <TableCell align="right">
                    <Button size="small" disabled={rates[s.memberId] === undefined || rates[s.memberId] === ''} onClick={() => saveRate(s)}>Save rate</Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
        <Typography variant="caption" color="text.secondary" sx={{ mt: 1, display: 'block' }}>
          Costs are calculated as hours x base rate when hours are submitted or edited.
        </Typography>
      </Box>
      <Notice notice={notice} onClose={() => setNotice(null)} />
    </Stack>
  );
}
