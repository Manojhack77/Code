import { useCallback, useEffect, useState } from 'react';
import {
  Button, Chip, Dialog, DialogActions, DialogContent, DialogTitle, Paper, Stack, Table, TableBody,
  TableCell, TableContainer, TableHead, TableRow, TextField,
} from '@mui/material';
import api, { errMsg } from '../../api';
import Notice from '../Notice.jsx';
import { money } from '../../util.js';

const empty = { wbsCode: '', projectName: '', expiryDate: '', amountAllotted: '' };

export default function ProjectsTab() {
  const [rows, setRows] = useState([]);
  const [form, setForm] = useState(null); // null = closed
  const [isNew, setIsNew] = useState(true);
  const [notice, setNotice] = useState(null);

  const load = useCallback(async () => {
    try {
      const { data } = await api.get('/admin/projects');
      setRows(data);
    } catch (e) {
      setNotice({ severity: 'error', text: errMsg(e) });
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const openNew = () => { setIsNew(true); setForm(empty); };
  const openEdit = (p) => {
    setIsNew(false);
    setForm({ wbsCode: p.wbsCode, projectName: p.projectName, expiryDate: p.expiryDate, amountAllotted: String(p.amountAllotted) });
  };
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const save = async () => {
    const body = { ...form, amountAllotted: Number(form.amountAllotted) };
    try {
      if (isNew) await api.post('/admin/projects', body);
      else await api.put(`/admin/projects/${form.wbsCode}`, body);
      setForm(null);
      setNotice({ severity: 'success', text: isNew ? 'Project created.' : 'Project updated.' });
      load();
    } catch (e) {
      setNotice({ severity: 'error', text: errMsg(e) });
    }
  };

  const valid = form && form.wbsCode.trim() && form.projectName.trim() && form.expiryDate && form.amountAllotted !== '';

  return (
    <Stack spacing={2}>
      <div><Button variant="contained" onClick={openNew}>New project</Button></div>
      <TableContainer component={Paper}>
        <Table size="small">
          <TableHead>
            <TableRow>
              <TableCell>WBS code</TableCell>
              <TableCell>Project name</TableCell>
              <TableCell>Expiry date</TableCell>
              <TableCell align="right">Amount allotted</TableCell>
              <TableCell align="right">Amount booked</TableCell>
              <TableCell align="right">Amount available</TableCell>
              <TableCell>Status</TableCell>
              <TableCell />
            </TableRow>
          </TableHead>
          <TableBody>
            {rows.length === 0 && <TableRow><TableCell colSpan={8}>No projects yet. Create the first one.</TableCell></TableRow>}
            {rows.map((p) => (
              <TableRow key={p.wbsCode} hover>
                <TableCell>{p.wbsCode}</TableCell>
                <TableCell>{p.projectName}</TableCell>
                <TableCell>{p.expiryDate}</TableCell>
                <TableCell align="right">{money(p.amountAllotted)}</TableCell>
                <TableCell align="right">{money(p.amountBooked)}</TableCell>
                <TableCell align="right">{money(p.amountAvailable)}</TableCell>
                <TableCell><Chip size="small" label={p.status} color={p.status === 'Expired' ? 'error' : 'success'} variant="outlined" /></TableCell>
                <TableCell align="right"><Button size="small" onClick={() => openEdit(p)}>Edit</Button></TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      <Dialog open={Boolean(form)} onClose={() => setForm(null)} fullWidth maxWidth="xs">
        <DialogTitle>{isNew ? 'New project' : 'Edit project'}</DialogTitle>
        <DialogContent>
          {form && (
            <Stack spacing={2} sx={{ mt: 1 }}>
              <TextField label="WBS code" value={form.wbsCode} onChange={set('wbsCode')} disabled={!isNew} required fullWidth />
              <TextField label="Project name" value={form.projectName} onChange={set('projectName')} required fullWidth />
              <TextField label="Expiry date" type="date" value={form.expiryDate} onChange={set('expiryDate')}
                InputLabelProps={{ shrink: true }} required fullWidth />
              <TextField label="Amount allotted" type="number" value={form.amountAllotted} onChange={set('amountAllotted')}
                inputProps={{ min: 0, step: 0.01 }} required fullWidth />
            </Stack>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setForm(null)}>Cancel</Button>
          <Button variant="contained" onClick={save} disabled={!valid}>{isNew ? 'Create project' : 'Save changes'}</Button>
        </DialogActions>
      </Dialog>
      <Notice notice={notice} onClose={() => setNotice(null)} />
    </Stack>
  );
}
