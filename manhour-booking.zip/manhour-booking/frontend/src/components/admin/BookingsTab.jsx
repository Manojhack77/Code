import { useCallback, useEffect, useState } from 'react';
import {
  Button, Dialog, DialogActions, DialogContent, DialogTitle, MenuItem, Paper, Stack, Table,
  TableBody, TableCell, TableContainer, TableHead, TableRow, TextField, Typography,
} from '@mui/material';
import api, { errMsg } from '../../api';
import Notice from '../Notice.jsx';
import { MONTHS, hoursFmt, money } from '../../util.js';

export default function BookingsTab() {
  const now = new Date();
  const [month, setMonth] = useState(now.getMonth() + 1); // 0 = all months
  const [year, setYear] = useState(String(now.getFullYear()));
  const [rows, setRows] = useState([]);
  const [edit, setEdit] = useState(null);
  const [hours, setHours] = useState('');
  const [notice, setNotice] = useState(null);

  // FR 5.3: filtering happens through fetch, without reloading the page
  const load = useCallback(async () => {
    const params = {};
    if (month) params.month = month;
    if (year) params.year = year;
    try {
      const { data } = await api.get('/admin/bookings', { params });
      setRows(data);
    } catch (e) {
      setNotice({ severity: 'error', text: errMsg(e) });
    }
  }, [month, year]);

  useEffect(() => { load(); }, [load]);

  const openEdit = (row) => { setEdit(row); setHours(String(row.hoursBooked)); };

  const save = async () => {
    try {
      await api.put(`/admin/bookings/${edit.bookingId}`, { hoursBooked: Number(hours) });
      setEdit(null);
      setNotice({ severity: 'success', text: 'Hours updated and budget recalculated.' });
      load();
    } catch (e) {
      setNotice({ severity: 'error', text: errMsg(e) });
    }
  };

  const totalHours = rows.reduce((s, r) => s + Number(r.hoursBooked), 0);
  const totalCost = rows.reduce((s, r) => s + Number(r.calculatedCost), 0);

  return (
    <Stack spacing={2}>
      <Stack direction="row" spacing={2}>
        <TextField select size="small" label="Month" value={month} onChange={(e) => setMonth(Number(e.target.value))} sx={{ minWidth: 160 }}>
          <MenuItem value={0}>All months</MenuItem>
          {MONTHS.map((m, i) => <MenuItem key={m} value={i + 1}>{m}</MenuItem>)}
        </TextField>
        <TextField size="small" label="Year" type="number" value={year} onChange={(e) => setYear(e.target.value)} sx={{ width: 110 }} />
      </Stack>

      <TableContainer component={Paper}>
        <Table size="small">
          <TableHead>
            <TableRow>
              <TableCell>WBS code</TableCell>
              <TableCell>Project</TableCell>
              <TableCell>Staff member</TableCell>
              <TableCell align="right">Hours booked</TableCell>
              <TableCell align="right">Cost</TableCell>
              <TableCell>Month</TableCell>
              <TableCell>Year</TableCell>
              <TableCell />
            </TableRow>
          </TableHead>
          <TableBody>
            {rows.length === 0 && <TableRow><TableCell colSpan={8}>No bookings for this period.</TableCell></TableRow>}
            {rows.map((r) => (
              <TableRow key={r.bookingId} hover>
                <TableCell>{r.wbsCode}</TableCell>
                <TableCell>{r.projectName}</TableCell>
                <TableCell>{r.staffName}</TableCell>
                <TableCell align="right">{hoursFmt(r.hoursBooked)}</TableCell>
                <TableCell align="right">{money(r.calculatedCost)}</TableCell>
                <TableCell>{MONTHS[r.month - 1]}</TableCell>
                <TableCell>{r.year}</TableCell>
                <TableCell align="right"><Button size="small" onClick={() => openEdit(r)}>Edit</Button></TableCell>
              </TableRow>
            ))}
            {rows.length > 0 && (
              <TableRow>
                <TableCell colSpan={3}><strong>Total</strong></TableCell>
                <TableCell align="right"><strong>{hoursFmt(totalHours)}</strong></TableCell>
                <TableCell align="right"><strong>{money(totalCost)}</strong></TableCell>
                <TableCell colSpan={3} />
              </TableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>

      <Dialog open={Boolean(edit)} onClose={() => setEdit(null)} fullWidth maxWidth="xs">
        <DialogTitle>Edit hours</DialogTitle>
        <DialogContent>
          {edit && (
            <Stack spacing={2} sx={{ mt: 1 }}>
              <Typography variant="body2">
                {edit.staffName} on {edit.wbsCode}, {MONTHS[edit.month - 1]} {edit.year}
              </Typography>
              <TextField label="Hours booked" type="number" value={hours} onChange={(e) => setHours(e.target.value)}
                inputProps={{ min: 0, step: 0.25 }} autoFocus fullWidth />
              <Typography variant="caption" color="text.secondary">
                The cost and the project budget are recalculated when you save.
              </Typography>
            </Stack>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setEdit(null)}>Cancel</Button>
          <Button variant="contained" onClick={save} disabled={!(Number(hours) > 0)}>Save changes</Button>
        </DialogActions>
      </Dialog>
      <Notice notice={notice} onClose={() => setNotice(null)} />
    </Stack>
  );
}
