import { Alert, Snackbar } from '@mui/material';

/** notice = { severity: 'success' | 'error', text: string } or null */
export default function Notice({ notice, onClose }) {
  return (
    <Snackbar
      open={Boolean(notice)}
      autoHideDuration={5000}
      onClose={onClose}
      anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
    >
      {notice ? <Alert severity={notice.severity} onClose={onClose} variant="filled">{notice.text}</Alert> : undefined}
    </Snackbar>
  );
}
