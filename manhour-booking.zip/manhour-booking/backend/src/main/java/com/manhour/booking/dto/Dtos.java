package com.manhour.booking.dto;

import jakarta.validation.constraints.*;

import java.math.BigDecimal;
import java.time.LocalDate;

public final class Dtos {
    private Dtos() {}

    // ----- requests -----
    public record RegisterRequest(
            @NotBlank(message = "Full name is required") @Size(max = 100) String fullName,
            @NotBlank(message = "Username is required")
            @Pattern(regexp = "^[A-Za-z0-9._-]{3,30}$",
                     message = "Username must be 3-30 characters: letters, numbers, dot, dash or underscore") String username,
            @NotBlank(message = "Password is required")
            @Size(min = 6, max = 72, message = "Password must be 6-72 characters") String password,
            @NotBlank(message = "Account role is required") String role) {}

    public record LoginRequest(@NotBlank(message = "Username is required") String username,
                               @NotBlank(message = "Password is required") String password) {}

    public record CreateBookingRequest(
            @NotBlank String wbsCode,
            @NotNull(message = "Hours are required") @DecimalMin(value = "0.01", message = "Hours must be greater than 0")
            @Digits(integer = 6, fraction = 2) BigDecimal hoursBooked,
            @NotNull Integer month,
            @NotNull Integer year) {}

    public record UpdateBookingRequest(
            @NotNull(message = "Hours are required") @DecimalMin(value = "0.01", message = "Hours must be greater than 0")
            @Digits(integer = 6, fraction = 2) BigDecimal hoursBooked) {}

    public record ProjectRequest(
            @NotBlank(message = "WBS code is required") @Size(max = 50) String wbsCode,
            @NotBlank(message = "Project name is required") @Size(max = 255) String projectName,
            @NotNull(message = "Expiry date is required") LocalDate expiryDate,
            @NotNull(message = "Amount allotted is required") @DecimalMin("0.00") @Digits(integer = 13, fraction = 2) BigDecimal amountAllotted) {}

    public record MappingRequest(
            @NotBlank(message = "Project is required") String wbsCode,
            @NotBlank(message = "Staff member is required") String memberId,
            @NotNull(message = "Allocation is required")
            @DecimalMin(value = "0.01", message = "Allocation must be more than 0%")
            @DecimalMax(value = "100", message = "Allocation cannot exceed 100%") BigDecimal allocationPercentage) {}

    public record RateRequest(@NotNull @DecimalMin("0.00") @Digits(integer = 10, fraction = 2) BigDecimal baseRate) {}

    // ----- responses -----
    public record AuthResponse(String token, String memberId, String name, String username, String role) {}

    public record BookingDto(Long bookingId, String wbsCode, String projectName, String memberId, String staffName,
                             BigDecimal hoursBooked, Integer month, Integer year, BigDecimal calculatedCost) {}

    public record ProjectDto(String wbsCode, String projectName, LocalDate expiryDate, BigDecimal amountAllotted,
                             BigDecimal amountAvailable, BigDecimal amountBooked, String status) {}

    public record MappingDto(Long mappingId, String wbsCode, String projectName, String memberId, String staffName,
                             BigDecimal allocationPercentage) {}

    public record StaffDto(String memberId, String name, String username, String role, BigDecimal baseRate) {}

    public record StaffProjectDto(String wbsCode, String projectName, LocalDate expiryDate, boolean expired,
                                  BigDecimal allocationPercentage, BigDecimal suggestedHours, BigDecimal baseRate) {}
}
