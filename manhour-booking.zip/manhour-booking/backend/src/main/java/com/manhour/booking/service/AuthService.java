package com.manhour.booking.service;

import com.manhour.booking.dto.Dtos.*;
import com.manhour.booking.entity.Role;
import com.manhour.booking.entity.Staff;
import com.manhour.booking.repo.StaffRepository;
import com.manhour.booking.security.JwtService;
import com.manhour.booking.web.ApiException;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;

@Service
@RequiredArgsConstructor
public class AuthService {
    private final StaffRepository staffRepo;
    private final PasswordEncoder encoder;
    private final JwtService jwt;

    @Value("${app.default-base-rate}")
    private BigDecimal defaultBaseRate;

    @Transactional
    public AuthResponse register(RegisterRequest r) {
        String username = r.username().trim().toLowerCase();
        if (staffRepo.existsByUsername(username)) {
            throw new ApiException(HttpStatus.CONFLICT, "That username is taken. Choose another one.");
        }
        Role role;
        try {
            role = Role.valueOf(r.role().trim().toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "Account role must be staff or admin.");
        }
        Staff s = new Staff();
        s.setMemberId(username);
        s.setUsername(username);
        s.setName(r.fullName().trim());
        s.setPassword(encoder.encode(r.password()));
        s.setRole(role);
        s.setBaseRate(defaultBaseRate);
        staffRepo.save(s);
        return toResponse(s);
    }

    @Transactional(readOnly = true)
    public AuthResponse login(LoginRequest r) {
        Staff s = staffRepo.findByUsername(r.username().trim().toLowerCase())
                .filter(u -> encoder.matches(r.password(), u.getPassword()))
                .orElseThrow(() -> new ApiException(HttpStatus.UNAUTHORIZED, "Wrong username or password."));
        return toResponse(s);
    }

    private AuthResponse toResponse(Staff s) {
        return new AuthResponse(jwt.generate(s), s.getMemberId(), s.getName(), s.getUsername(), s.getRole().name());
    }
}
