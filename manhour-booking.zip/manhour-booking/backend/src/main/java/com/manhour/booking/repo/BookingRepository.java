package com.manhour.booking.repo;

import com.manhour.booking.entity.Booking;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface BookingRepository extends JpaRepository<Booking, Long> {
    @Query("select b from Booking b " +
           "where (:month is null or b.month = :month) and (:year is null or b.year = :year) " +
           "order by b.year desc, b.month desc, b.project.wbsCode, b.staff.name")
    List<Booking> search(@Param("month") Integer month, @Param("year") Integer year);

    List<Booking> findByStaffMemberIdOrderByYearDescMonthDesc(String memberId);

    boolean existsByProjectWbsCodeAndStaffMemberIdAndMonthAndYear(String wbsCode, String memberId, Integer month, Integer year);
}
