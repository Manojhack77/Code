package com.manhour.booking.entity;

public enum Role { STAFF, ADMIN }
