package com.manhour.booking.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@Entity
@Table(name = "project_member_mapping",
        uniqueConstraints = @UniqueConstraint(columnNames = {"wbs_code", "member_id"}))
@Getter @Setter @NoArgsConstructor
public class ProjectMemberMapping {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "mapping_id")
    private Long mappingId;

    @ManyToOne(optional = false)
    @JoinColumn(name = "wbs_code")
    private Project project;

    @ManyToOne(optional = false)
    @JoinColumn(name = "member_id")
    private Staff staff;

    @Column(name = "allocation_percentage", nullable = false, precision = 5, scale = 2)
    private BigDecimal allocationPercentage;
}
