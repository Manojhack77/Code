package com.manhour.booking.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@Entity
@Table(name = "booking",
        uniqueConstraints = @UniqueConstraint(columnNames = {"wbs_code", "member_id", "booking_month", "booking_year"}))
@Getter @Setter @NoArgsConstructor
public class Booking {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "booking_id")
    private Long bookingId;

    @ManyToOne(optional = false)
    @JoinColumn(name = "wbs_code")
    private Project project;

    @ManyToOne(optional = false)
    @JoinColumn(name = "member_id")
    private Staff staff;

    @Column(name = "hours_booked", nullable = false, precision = 8, scale = 2)
    private BigDecimal hoursBooked;

    // "month" and "year" are reserved words in some SQL dialects, so the columns get a prefix
    @Column(name = "booking_month", nullable = false)
    private Integer month;

    @Column(name = "booking_year", nullable = false)
    private Integer year;

    @Column(name = "calculated_cost", nullable = false, precision = 15, scale = 2)
    private BigDecimal calculatedCost;
}
