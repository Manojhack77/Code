package com.manhour.booking.web;

import com.manhour.booking.dto.Dtos.*;
import com.manhour.booking.service.BookingService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/staff")
@RequiredArgsConstructor
public class StaffController {
    private final BookingService bookings;

    @GetMapping("/projects")
    public List<StaffProjectDto> projects(Authentication auth) {
        return bookings.assignedProjects(auth.getName());
    }

    @GetMapping("/bookings")
    public List<BookingDto> history(Authentication auth) {
        return bookings.myBookings(auth.getName());
    }

    @PostMapping("/bookings")
    @ResponseStatus(HttpStatus.CREATED)
    public BookingDto create(Authentication auth, @Valid @RequestBody CreateBookingRequest r) {
        return bookings.create(auth.getName(), r);
    }
}
