package com.manhour.booking.web;

import com.manhour.booking.dto.Dtos.*;
import com.manhour.booking.service.BookingService;
import com.manhour.booking.service.ProjectService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/admin")
@RequiredArgsConstructor
public class AdminController {
    private final BookingService bookings;
    private final ProjectService projects;

    // FR-2.1 / FR-2.2 dashboard
    @GetMapping("/bookings")
    public List<BookingDto> bookings(@RequestParam(required = false) Integer month,
                                     @RequestParam(required = false) Integer year) {
        return bookings.search(month, year);
    }

    @PutMapping("/bookings/{id}")
    public BookingDto editBooking(@PathVariable Long id, @Valid @RequestBody UpdateBookingRequest r) {
        return bookings.adminEdit(id, r);
    }

    // FR-2.3 projects
    @GetMapping("/projects")
    public List<ProjectDto> projects() {
        return projects.listProjects();
    }

    @PostMapping("/projects")
    @ResponseStatus(HttpStatus.CREATED)
    public ProjectDto createProject(@Valid @RequestBody ProjectRequest r) {
        return projects.create(r);
    }

    @PutMapping("/projects/{wbsCode}")
    public ProjectDto updateProject(@PathVariable String wbsCode, @Valid @RequestBody ProjectRequest r) {
        return projects.update(wbsCode, r);
    }

    // staff
    @GetMapping("/staff")
    public List<StaffDto> staff() {
        return projects.listStaff();
    }

    @PutMapping("/staff/{memberId}/rate")
    public StaffDto setRate(@PathVariable String memberId, @Valid @RequestBody RateRequest r) {
        return projects.setRate(memberId, r.baseRate());
    }

    // FR-2.4 member mapping
    @GetMapping("/mappings")
    public List<MappingDto> mappings() {
        return projects.listMappings();
    }

    @PostMapping("/mappings")
    public MappingDto saveMapping(@Valid @RequestBody MappingRequest r) {
        return projects.saveMapping(r);
    }

    @DeleteMapping("/mappings/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteMapping(@PathVariable Long id) {
        projects.deleteMapping(id);
    }
}
