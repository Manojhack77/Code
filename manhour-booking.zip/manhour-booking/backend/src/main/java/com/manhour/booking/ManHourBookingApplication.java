package com.manhour.booking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ManHourBookingApplication {
    public static void main(String[] args) {
        SpringApplication.run(ManHourBookingApplication.class, args);
    }
}
