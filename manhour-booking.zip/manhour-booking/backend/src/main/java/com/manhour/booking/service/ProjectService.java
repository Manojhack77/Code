package com.manhour.booking.service;

import com.manhour.booking.dto.Dtos.*;
import com.manhour.booking.entity.*;
import com.manhour.booking.repo.*;
import com.manhour.booking.web.ApiException;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Comparator;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ProjectService {
    private final ProjectRepository projects;
    private final MappingRepository mappings;
    private final StaffRepository staffRepo;

    // ---------- projects (FR-2.3) ----------

    @Transactional(readOnly = true)
    public List<ProjectDto> listProjects() {
        return projects.findAll().stream()
                .sorted(Comparator.comparing(Project::getWbsCode))
                .map(Mapper::project).toList();
    }

    @Transactional
    public ProjectDto create(ProjectRequest r) {
        String wbs = r.wbsCode().trim();
        if (projects.existsById(wbs)) {
            throw new ApiException(HttpStatus.CONFLICT, "A project with WBS code " + wbs + " already exists.");
        }
        Project p = new Project();
        p.setWbsCode(wbs);
        p.setProjectName(r.projectName().trim());
        p.setExpiryDate(r.expiryDate());
        BigDecimal allotted = r.amountAllotted().setScale(2, RoundingMode.HALF_UP);
        p.setAmountAllotted(allotted);
        p.setAmountBooked(BigDecimal.ZERO.setScale(2));
        p.setAmountAvailable(allotted);
        return Mapper.project(projects.save(p));
    }

    @Transactional
    public ProjectDto update(String wbsCode, ProjectRequest r) {
        Project p = projects.findForUpdate(wbsCode)
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Project not found."));
        BigDecimal newAllotted = r.amountAllotted().setScale(2, RoundingMode.HALF_UP);
        boolean budgetChanged = newAllotted.compareTo(p.getAmountAllotted()) != 0;

        // FR-3.4: no budget updates once expired (extend the expiry date first to reopen it)
        if (p.expired() && budgetChanged) {
            throw new ApiException(HttpStatus.UNPROCESSABLE_ENTITY,
                    "Project has expired, so its budget is locked. Extend the expiry date first.");
        }
        if (newAllotted.compareTo(p.getAmountBooked()) < 0) {
            throw new ApiException(HttpStatus.UNPROCESSABLE_ENTITY,
                    "Amount allotted cannot be lower than the amount already booked (" + p.getAmountBooked() + ").");
        }
        p.setProjectName(r.projectName().trim());
        p.setExpiryDate(r.expiryDate());
        p.changeAllotted(newAllotted);
        return Mapper.project(projects.save(p));
    }

    // ---------- staff list ----------

    @Transactional(readOnly = true)
    public List<StaffDto> listStaff() {
        return staffRepo.findAll().stream()
                .sorted(Comparator.comparing(Staff::getName, String.CASE_INSENSITIVE_ORDER))
                .map(Mapper::staff).toList();
    }

    @Transactional
    public StaffDto setRate(String memberId, BigDecimal rate) {
        Staff s = staffRepo.findById(memberId)
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Staff member not found."));
        s.setBaseRate(rate.setScale(2, RoundingMode.HALF_UP));
        return Mapper.staff(staffRepo.save(s));
    }

    // ---------- member mapping (FR-2.4) ----------

    @Transactional(readOnly = true)
    public List<MappingDto> listMappings() {
        return mappings.findAll().stream()
                .sorted(Comparator.comparing((ProjectMemberMapping m) -> m.getProject().getWbsCode())
                        .thenComparing(m -> m.getStaff().getName()))
                .map(Mapper::mapping).toList();
    }

    /** Creates the mapping or updates its percentage; a staff member's total across projects stays <= 100%. */
    @Transactional
    public MappingDto saveMapping(MappingRequest r) {
        Project p = projects.findById(r.wbsCode())
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Project not found."));
        Staff s = staffRepo.findById(r.memberId())
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Staff member not found."));
        if (s.getRole() != Role.STAFF) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "Only staff accounts can be mapped to projects.");
        }
        BigDecimal pct = r.allocationPercentage().setScale(2, RoundingMode.HALF_UP);
        BigDecimal others = mappings.sumOtherAllocations(s.getMemberId(), p.getWbsCode());
        if (others.add(pct).compareTo(BigDecimal.valueOf(100)) > 0) {
            BigDecimal room = BigDecimal.valueOf(100).subtract(others);
            throw new ApiException(HttpStatus.UNPROCESSABLE_ENTITY,
                    s.getName() + " is already allocated " + others + "% on other projects. At most " + room + "% is left.");
        }
        ProjectMemberMapping m = mappings.findByProjectWbsCodeAndStaffMemberId(p.getWbsCode(), s.getMemberId())
                .orElseGet(ProjectMemberMapping::new);
        m.setProject(p);
        m.setStaff(s);
        m.setAllocationPercentage(pct);
        return Mapper.mapping(mappings.save(m));
    }

    @Transactional
    public void deleteMapping(Long id) {
        if (!mappings.existsById(id)) throw new ApiException(HttpStatus.NOT_FOUND, "Mapping not found.");
        mappings.deleteById(id);
    }
}
