package com.manhour.booking.service;

import com.manhour.booking.dto.Dtos.*;
import com.manhour.booking.entity.*;
import com.manhour.booking.repo.*;
import com.manhour.booking.web.ApiException;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

/**
 * Core engine: cost calculation (FR-3.1), budget dynamics (FR-3.2),
 * invariant (FR-3.3) and expiry lock (FR-3.4). All money maths uses BigDecimal
 * and every write runs inside one transaction (all or nothing).
 */
@Service
@RequiredArgsConstructor
public class BookingService {
    private static final BigDecimal MAX_HOURS_PER_MONTH = new BigDecimal("744");

    private final BookingRepository bookings;
    private final ProjectRepository projects;
    private final StaffRepository staffRepo;
    private final MappingRepository mappings;

    @Value("${app.standard-monthly-hours}")
    private BigDecimal standardMonthlyHours;

    // ---------- staff ----------

    @Transactional(readOnly = true)
    public List<StaffProjectDto> assignedProjects(String username) {
        Staff s = requireStaff(username);
        return mappings.findByStaffMemberId(s.getMemberId()).stream()
                .map(m -> new StaffProjectDto(
                        m.getProject().getWbsCode(), m.getProject().getProjectName(),
                        m.getProject().getExpiryDate(), m.getProject().expired(),
                        m.getAllocationPercentage(),
                        // FR: initial man-hours are based on the allocation percentage (editable by the user)
                        standardMonthlyHours.multiply(m.getAllocationPercentage())
                                .divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP),
                        s.getBaseRate()))
                .toList();
    }

    @Transactional(readOnly = true)
    public List<BookingDto> myBookings(String username) {
        Staff s = requireStaff(username);
        return bookings.findByStaffMemberIdOrderByYearDescMonthDesc(s.getMemberId())
                .stream().map(Mapper::booking).toList();
    }

    @Transactional
    public BookingDto create(String username, CreateBookingRequest r) {
        Staff s = requireStaff(username);
        validatePeriod(r.month(), r.year());
        BigDecimal hours = validHours(r.hoursBooked());

        // FR-1.1: staff can only book against projects they are mapped to
        mappings.findByProjectWbsCodeAndStaffMemberId(r.wbsCode(), s.getMemberId())
                .orElseThrow(() -> new ApiException(HttpStatus.FORBIDDEN, "You are not assigned to this project."));

        Project p = lockProject(r.wbsCode());
        ensureActive(p);

        if (bookings.existsByProjectWbsCodeAndStaffMemberIdAndMonthAndYear(
                r.wbsCode(), s.getMemberId(), r.month(), r.year())) {
            throw new ApiException(HttpStatus.CONFLICT,
                    "Hours for this project and month are already submitted. Ask an administrator to edit them.");
        }

        BigDecimal cost = cost(hours, s);
        reserve(p, cost);

        Booking b = new Booking();
        b.setProject(p);
        b.setStaff(s);
        b.setHoursBooked(hours);
        b.setMonth(r.month());
        b.setYear(r.year());
        b.setCalculatedCost(cost);
        return Mapper.booking(bookings.save(b));
    }

    // ---------- admin ----------

    @Transactional(readOnly = true)
    public List<BookingDto> search(Integer month, Integer year) {
        return bookings.search(month, year).stream().map(Mapper::booking).toList();
    }

    @Transactional
    public BookingDto adminEdit(Long bookingId, UpdateBookingRequest r) {
        Booking b = bookings.findById(bookingId)
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Booking not found."));
        BigDecimal hours = validHours(r.hoursBooked());

        Project p = lockProject(b.getProject().getWbsCode());
        ensureActive(p);

        BigDecimal newCost = cost(hours, b.getStaff());
        BigDecimal delta = newCost.subtract(b.getCalculatedCost());
        reserve(p, delta);

        b.setHoursBooked(hours);
        b.setCalculatedCost(newCost);
        return Mapper.booking(bookings.save(b));
    }

    // ---------- helpers ----------

    /** FR-3.1: Booking Cost = Hours Booked x Base Rate. */
    private BigDecimal cost(BigDecimal hours, Staff s) {
        return hours.multiply(s.getBaseRate()).setScale(2, RoundingMode.HALF_UP);
    }

    /** FR-3.2: Booked += cost, Available = Allotted - Booked. Negative delta releases budget. */
    private void reserve(Project p, BigDecimal delta) {
        if (delta.compareTo(p.getAmountAvailable()) > 0) {
            throw new ApiException(HttpStatus.UNPROCESSABLE_ENTITY,
                    "Not enough budget on " + p.getWbsCode() + ". Available: " + p.getAmountAvailable()
                            + ", needed: " + delta + ".");
        }
        p.applyBookingDelta(delta);
        projects.save(p);
    }

    /** FR-3.4: expired projects accept no bookings or budget changes. */
    private void ensureActive(Project p) {
        if (p.expired()) {
            throw new ApiException(HttpStatus.UNPROCESSABLE_ENTITY,
                    "Project " + p.getWbsCode() + " expired on " + p.getExpiryDate() + ". No bookings can be added or changed.");
        }
    }

    private Project lockProject(String wbs) {
        return projects.findForUpdate(wbs)
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Project " + wbs + " not found."));
    }

    private Staff requireStaff(String username) {
        return staffRepo.findByUsername(username)
                .orElseThrow(() -> new ApiException(HttpStatus.UNAUTHORIZED, "User not found."));
    }

    private void validatePeriod(Integer month, Integer year) {
        if (month < 1 || month > 12) throw new ApiException(HttpStatus.BAD_REQUEST, "Month must be between 1 and 12.");
        if (year < 2000 || year > 2100) throw new ApiException(HttpStatus.BAD_REQUEST, "Enter a valid year.");
    }

    private BigDecimal validHours(BigDecimal hours) {
        BigDecimal h = hours.setScale(2, RoundingMode.HALF_UP);
        if (h.compareTo(MAX_HOURS_PER_MONTH) > 0) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "Hours cannot exceed " + MAX_HOURS_PER_MONTH + " in a month.");
        }
        return h;
    }
}
