package com.manhour.booking.repo;

import com.manhour.booking.entity.Staff;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface StaffRepository extends JpaRepository<Staff, String> {
    Optional<Staff> findByUsername(String username);
    boolean existsByUsername(String username);
}
