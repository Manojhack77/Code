package com.manhour.booking.repo;

import com.manhour.booking.entity.ProjectMemberMapping;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

public interface MappingRepository extends JpaRepository<ProjectMemberMapping, Long> {
    List<ProjectMemberMapping> findByStaffMemberId(String memberId);

    Optional<ProjectMemberMapping> findByProjectWbsCodeAndStaffMemberId(String wbsCode, String memberId);

    @Query("select coalesce(sum(m.allocationPercentage), 0) from ProjectMemberMapping m " +
           "where m.staff.memberId = :memberId and m.project.wbsCode <> :wbs")
    BigDecimal sumOtherAllocations(@Param("memberId") String memberId, @Param("wbs") String wbs);
}
