package com.manhour.booking.repo;

import com.manhour.booking.entity.Project;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

public interface ProjectRepository extends JpaRepository<Project, String> {
    /** Row lock so two simultaneous bookings cannot overspend the same budget. */
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select p from Project p where p.wbsCode = :wbs")
    Optional<Project> findForUpdate(@Param("wbs") String wbs);
}
