package com.manhour.booking.service;

import com.manhour.booking.dto.Dtos.*;
import com.manhour.booking.entity.*;

final class Mapper {
    private Mapper() {}

    static BookingDto booking(Booking b) {
        return new BookingDto(b.getBookingId(), b.getProject().getWbsCode(), b.getProject().getProjectName(),
                b.getStaff().getMemberId(), b.getStaff().getName(), b.getHoursBooked(), b.getMonth(),
                b.getYear(), b.getCalculatedCost());
    }

    static ProjectDto project(Project p) {
        return new ProjectDto(p.getWbsCode(), p.getProjectName(), p.getExpiryDate(), p.getAmountAllotted(),
                p.getAmountAvailable(), p.getAmountBooked(), p.expired() ? "Expired" : "Active");
    }

    static MappingDto mapping(ProjectMemberMapping m) {
        return new MappingDto(m.getMappingId(), m.getProject().getWbsCode(), m.getProject().getProjectName(),
                m.getStaff().getMemberId(), m.getStaff().getName(), m.getAllocationPercentage());
    }

    static StaffDto staff(Staff s) {
        return new StaffDto(s.getMemberId(), s.getName(), s.getUsername(), s.getRole().name(), s.getBaseRate());
    }
}
