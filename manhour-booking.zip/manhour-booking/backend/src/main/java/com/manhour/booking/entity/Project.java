package com.manhour.booking.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "project")
@Getter @Setter @NoArgsConstructor
public class Project {
    @Id
    @Column(name = "wbs_code", length = 50)
    private String wbsCode;

    @Column(name = "project_name", nullable = false)
    private String projectName;

    @Column(name = "expiry_date", nullable = false)
    private LocalDate expiryDate;

    @Column(name = "amount_allotted", nullable = false, precision = 15, scale = 2)
    private BigDecimal amountAllotted = BigDecimal.ZERO;

    @Column(name = "amount_available", nullable = false, precision = 15, scale = 2)
    private BigDecimal amountAvailable = BigDecimal.ZERO;

    @Column(name = "amount_booked", nullable = false, precision = 15, scale = 2)
    private BigDecimal amountBooked = BigDecimal.ZERO;

    public boolean expired() {
        return expiryDate.isBefore(LocalDate.now());
    }

    /** FR-3.2: add (or, when negative, release) cost and keep the invariant. */
    public void applyBookingDelta(BigDecimal delta) {
        amountBooked = amountBooked.add(delta);
        amountAvailable = amountAllotted.subtract(amountBooked);
        assertInvariant();
    }

    /** Changes the budget; available is always recomputed from allotted - booked. */
    public void changeAllotted(BigDecimal newAllotted) {
        amountAllotted = newAllotted;
        amountAvailable = amountAllotted.subtract(amountBooked);
        assertInvariant();
    }

    /** FR-3.3: Amount Allotted = Amount Available + Amount Booked. */
    private void assertInvariant() {
        if (amountAvailable.add(amountBooked).compareTo(amountAllotted) != 0) {
            throw new IllegalStateException("Budget invariant violated for " + wbsCode);
        }
    }
}
