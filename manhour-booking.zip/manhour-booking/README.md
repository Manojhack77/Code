# ManHourBooking

Spring Boot 3 (Java 17) + MySQL backend and React (Vite + Material UI) frontend.

## Run it

1. **MySQL**: have a server on `localhost:3306`. Edit `backend/src/main/resources/application.properties`
   (username/password). The `manhourbooking` database and tables are created on first start.
2. **Backend**
   ```
   cd backend
   mvn spring-boot:run
   ```
   Runs on http://localhost:8080
3. **Frontend**
   ```
   cd frontend
   npm install
   npm run dev
   ```
   Open http://localhost:5173 (the dev server proxies `/api` to the backend).

## First use

1. Register an **Admin** account, then sign in.
2. Projects tab: create a project (WBS code, name, expiry, amount allotted).
3. Register one or more **Staff** accounts (use a private window or sign out first).
4. Staff and mapping tab: assign staff to projects with an allocation %. Set base rates if needed.
5. Staff sign in, pick month and year, review the pre-filled hours and submit.
6. Admin: Bookings tab filters by month/year without a reload and lets you edit hours.

## How the rules are implemented

| Requirement | Where |
|---|---|
| FR-1.1 staff see only mapped projects | `BookingService.assignedProjects`, checked again in `create` |
| FR-1.2 hours per month and year | `POST /api/staff/bookings` |
| FR-2.1 / 2.2 dashboard and edit | `GET /api/admin/bookings`, `PUT /api/admin/bookings/{id}` |
| FR-2.3 project management | `ProjectService`, `/api/admin/projects` |
| FR-2.4 mapping, total <= 100% per staff | `ProjectService.saveMapping` |
| FR-3.1 cost = hours x base rate | `BookingService.cost` |
| FR-3.2 booked/available update | `BookingService.reserve`, `Project.applyBookingDelta` |
| FR-3.3 allotted = available + booked | `Project.assertInvariant` |
| FR-3.4 expiry lock | `BookingService.ensureActive`, `ProjectService.update` |
| 5.1 BigDecimal, @Transactional | all money maths; row lock on the project during booking |
| 5.2 RBAC + JWT | `SecurityConfig`, `JwtAuthFilter` |

## Decisions where the spec was open

- **Base rate** is per staff member (default `app.default-base-rate`), editable by admins.
- **Initial hours** = allocation % x `app.standard-monthly-hours` (160). Staff can edit before submitting.
- **One booking** per staff, project, month and year. Staff cannot resubmit; admins edit.
- **Expiry**: bookings and budget changes are refused after the expiry date. Extending the expiry date is allowed and reopens the project.
- **Register with role "admin"** is open, as in your sketch. Before real use, restrict it (invite code or admin-only creation).
- Editing an existing booking recalculates cost using the staff member's current base rate.
