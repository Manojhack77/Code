# API contract (for the Spring Boot backend)

The frontend calls these endpoints when `VITE_USE_MOCK=false`. JWT goes in `Authorization: Bearer <token>`.
Errors: HTTP 4xx with JSON `{ "message": "..." }` (the UI shows `message` as-is). 401 sends the user to /login.
Money uses BigDecimal; months are integers 1-12.

## Auth (public)
- POST /api/auth/login   `{ userId, password }` -> `{ token, user: { memberId, name, role } }`  (role: STAFF | ADMIN)
- POST /api/auth/signup  `{ memberId, name, password }` -> same shape. Always creates STAFF.

## Staff (role STAFF)
- GET   /api/staff/projects/{memberId} -> `[{ wbsCode, projectName, expiryDate, status, allocationPercentage, ... }]` (only mapped projects, FR-1.1)
- GET   /api/staff/history/{memberId}  -> `[{ id, month, year, hours }]` one row per month (sum over WBS rows), newest first
- POST  /api/staff/book `{ memberId, month, year, hours }`
  Creates one Booking row per mapped WBS: hours_wbs = hours x allocation%, calculated_cost = hours_wbs x baseRate.
  Rejects: month already booked, project expired, cost > amount_available. Single @Transactional.
- PATCH /api/staff/update-hours/{id}?hours=  
  Staff: `id` is the `id` from history (mock uses `<memberId>_<year>_<month>`; the backend may choose any opaque id) and the new total is re-split across that month's WBS rows.
  Admin: `id` is a booking_id and only that row changes. Both recalculate Amount Booked / Available.

## Admin (role ADMIN)
- GET    /api/admin/bookings?month=&year=  -> `[{ bookingId, wbsCode, projectName, memberId, staffName, hoursBooked, calculatedCost, month, year, projectExpired }]`
- GET    /api/admin/projects -> `[{ wbsCode, projectName, expiryDate, amountAllotted, amountAvailable, amountBooked, status }]` (status = Expired when expiryDate < today)
- POST   /api/admin/projects `{ wbsCode, projectName, expiryDate, amountAllotted }`
- PUT    /api/admin/projects/{wbsCode} `{ projectName, expiryDate, amountAllotted }`  (available = allotted - booked; reject allotted < booked)
- DELETE /api/admin/projects/{wbsCode}  (reject if bookings exist)
- GET    /api/admin/staff -> `[{ memberId, name, totalAllocation }]`
- GET    /api/admin/mappings -> `[{ mappingId, wbsCode, projectName, memberId, staffName, allocationPercentage, projectExpired }]`
- POST   /api/admin/mappings `{ memberId, wbsCode, allocationPercentage }`  (reject if staff total > 100, duplicate pair, or expired project)
- DELETE /api/admin/mappings/{mappingId}

## Rules the backend must enforce (spec FR-3.x, section 5)
Amount Booked += cost; Amount Available -= cost; Available = Allotted - Booked always; expired projects lock all booking and budget changes; RBAC on every route.
Base rate is currently a constant in `src/config.js` (500). Keep it in sync or move it to the backend.
