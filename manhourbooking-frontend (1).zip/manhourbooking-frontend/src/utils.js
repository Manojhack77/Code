export const MONTHS = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December",
];

export const monthName = (m) => MONTHS[Number(m) - 1] ?? "";

export const fmtMoney = (n) =>
  new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 2,
  }).format(Number(n) || 0);

export const fmtHours = (n) => `${Number(n) || 0}`;

export const isExpired = (isoDate) => {
  const t = new Date();
  t.setHours(0, 0, 0, 0);
  return new Date(`${isoDate}T00:00:00`) < t;
};

export const errMsg = (e) =>
  e?.response?.data?.message || e?.message || "Something went wrong. Please try again.";
