import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { Button } from "./ui";
import { isMock } from "../api";

export default function AppShell({ children }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate("/login", { replace: true });
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="border-b border-slate-200 bg-white">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-6 py-3.5">
          <div>
            <p className="text-base font-semibold text-slate-800">ManHourBooking</p>
            {isMock && <p className="text-xs text-amber-700">Demo mode: data is saved in this browser only</p>}
          </div>
          <div className="flex items-center gap-4">
            <p className="text-sm text-slate-600">
              {user.role === "ADMIN" ? "Administrator" : "Welcome"}, <span className="font-medium text-slate-800">{user.name}</span>
              <span className="mx-2 text-slate-300">|</span>
              ID: {user.memberId}
            </p>
            <Button variant="secondary" small onClick={handleLogout}>
              Log out
            </Button>
          </div>
        </div>
      </header>
      <main className="mx-auto max-w-6xl px-6 py-8">{children}</main>
    </div>
  );
}
