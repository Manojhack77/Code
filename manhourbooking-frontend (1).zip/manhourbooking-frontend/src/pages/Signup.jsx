import { useState } from "react";
import { Link, Navigate, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { homeFor } from "../components/ProtectedRoute";
import { Alert, Button, Card, Field, inputCls } from "../components/ui";
import { errMsg } from "../utils";

export default function Signup() {
  const { user, signup } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ memberId: "", name: "", password: "", confirm: "" });
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  if (user) return <Navigate to={homeFor(user)} replace />;

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const submit = async (e) => {
    e.preventDefault();
    if (!form.memberId.trim() || !form.name.trim() || !form.password) return setError("Fill in all fields.");
    if (form.password.length < 6) return setError("Password must be at least 6 characters.");
    if (form.password !== form.confirm) return setError("Passwords do not match.");
    setBusy(true);
    setError("");
    try {
      // Sign-up always creates a Staff account. Administrators are created by the system owner.
      await signup({ memberId: form.memberId.trim(), name: form.name.trim(), password: form.password });
      navigate("/staff", { replace: true });
    } catch (err) {
      setError(errMsg(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-slate-50 p-4">
      <div className="w-full max-w-sm">
        <h1 className="mb-1 text-2xl font-semibold text-slate-800">Create your account</h1>
        <p className="mb-6 text-sm text-slate-500">Use your staff ID. An administrator will assign you to projects.</p>

        <Card className="p-6">
          <form onSubmit={submit} className="space-y-4" noValidate>
            <Field label="Staff ID">
              <input className={inputCls} value={form.memberId} onChange={set("memberId")} autoComplete="username" autoFocus />
            </Field>
            <Field label="Full name">
              <input className={inputCls} value={form.name} onChange={set("name")} autoComplete="name" />
            </Field>
            <Field label="Password" hint="At least 6 characters.">
              <input type="password" className={inputCls} value={form.password} onChange={set("password")} autoComplete="new-password" />
            </Field>
            <Field label="Confirm password">
              <input type="password" className={inputCls} value={form.confirm} onChange={set("confirm")} autoComplete="new-password" />
            </Field>
            <Alert>{error}</Alert>
            <Button type="submit" className="w-full" disabled={busy}>
              {busy ? "Creating account..." : "Create account"}
            </Button>
          </form>
        </Card>

        <p className="mt-4 text-center text-sm text-slate-600">
          Already registered?{" "}
          <Link to="/login" className="font-medium text-blue-600 hover:text-blue-800">
            Log in
          </Link>
        </p>
      </div>
    </div>
  );
}
