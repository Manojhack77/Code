import { useCallback, useEffect, useState } from "react";
import { api } from "../../api";
import { Alert, Badge, Button, Card, EmptyRow, Field, Modal, Td, Th, inputCls } from "../../components/ui";
import { errMsg, fmtMoney } from "../../utils";

const EMPTY = { wbsCode: "", projectName: "", expiryDate: "", amountAllotted: "" };

// FR-2.3: project CRUD. Booked/available are computed by the system, never typed in.
export default function ProjectsTab() {
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [editing, setEditing] = useState(null); // null | "new" | project
  const [deleting, setDeleting] = useState(null);

  const load = useCallback(async () => {
    try {
      setProjects(await api.adminProjects());
    } catch (e) {
      setError(errMsg(e));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const remove = async () => {
    try {
      await api.deleteProject(deleting.wbsCode);
      setNotice(`${deleting.wbsCode} deleted.`);
      setError("");
      await load();
    } catch (e) {
      setError(errMsg(e));
      setNotice("");
    }
    setDeleting(null);
  };

  return (
    <div>
      <div className="mb-5 flex items-end justify-between gap-4">
        <div>
          <h2 className="text-xl font-semibold text-slate-800">Projects</h2>
          <p className="mt-1 text-sm text-slate-500">WBS codes, expiry dates and budgets.</p>
        </div>
        <Button onClick={() => setEditing("new")}>Add project</Button>
      </div>

      <div className="mb-4 space-y-2">
        <Alert>{error}</Alert>
        <Alert type="success">{notice}</Alert>
      </div>

      <Card className="overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="border-b border-slate-200 bg-slate-50">
              <tr>
                <Th>WBS code</Th>
                <Th>Project name</Th>
                <Th>Expiry date</Th>
                <Th>Allotted</Th>
                <Th>Booked</Th>
                <Th>Available</Th>
                <Th>Status</Th>
                <Th right>Action</Th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {loading ? (
                <EmptyRow cols={8}>Loading...</EmptyRow>
              ) : projects.length === 0 ? (
                <EmptyRow cols={8}>No projects yet. Add one to start assigning staff.</EmptyRow>
              ) : (
                projects.map((p) => {
                  const used = p.amountAllotted ? Math.min(100, (p.amountBooked / p.amountAllotted) * 100) : 0;
                  return (
                    <tr key={p.wbsCode} className="hover:bg-slate-50">
                      <Td strong>{p.wbsCode}</Td>
                      <Td>{p.projectName}</Td>
                      <Td>{p.expiryDate}</Td>
                      <Td>{fmtMoney(p.amountAllotted)}</Td>
                      <Td>
                        {fmtMoney(p.amountBooked)}
                        <div className="mt-1 h-1.5 w-24 overflow-hidden rounded-full bg-slate-100" aria-hidden="true">
                          <div className={`h-full ${used > 90 ? "bg-red-500" : "bg-blue-500"}`} style={{ width: `${used}%` }} />
                        </div>
                      </Td>
                      <Td strong>{fmtMoney(p.amountAvailable)}</Td>
                      <Td>{p.status === "Expired" ? <Badge tone="red">Expired</Badge> : <Badge tone="green">Active</Badge>}</Td>
                      <Td right>
                        <span className="inline-flex gap-1">
                          <Button small variant="ghost" onClick={() => setEditing(p)}>Edit</Button>
                          <Button small variant="ghost" className="!text-red-600 hover:!bg-red-50" onClick={() => setDeleting(p)}>Delete</Button>
                        </span>
                      </Td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </Card>

      {editing && (
        <ProjectForm
          project={editing === "new" ? null : editing}
          onClose={() => setEditing(null)}
          onSaved={async (msg) => {
            setEditing(null);
            setNotice(msg);
            setError("");
            await load();
          }}
        />
      )}

      {deleting && (
        <Modal title="Delete project?" onClose={() => setDeleting(null)}>
          <p className="text-sm text-slate-600">
            {deleting.projectName} ({deleting.wbsCode}) and its staff mappings will be removed. Projects with bookings cannot be deleted.
          </p>
          <div className="mt-5 flex justify-end gap-3">
            <Button variant="secondary" onClick={() => setDeleting(null)}>Cancel</Button>
            <Button variant="danger" onClick={remove}>Delete project</Button>
          </div>
        </Modal>
      )}
    </div>
  );
}

function ProjectForm({ project, onClose, onSaved }) {
  const isNew = !project;
  const [form, setForm] = useState(
    isNew ? EMPTY : { ...project, amountAllotted: String(project.amountAllotted) },
  );
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const submit = async (e) => {
    e.preventDefault();
    if (!form.wbsCode.trim() || !form.projectName.trim() || !form.expiryDate)
      return setError("WBS code, project name and expiry date are required.");
    if (!(Number(form.amountAllotted) > 0)) return setError("Amount allotted must be greater than zero.");
    setBusy(true);
    setError("");
    const body = {
      wbsCode: form.wbsCode.trim(),
      projectName: form.projectName.trim(),
      expiryDate: form.expiryDate,
      amountAllotted: Number(form.amountAllotted),
    };
    try {
      if (isNew) await api.createProject(body);
      else await api.updateProject(project.wbsCode, body);
      await onSaved(isNew ? `${body.wbsCode.toUpperCase()} created.` : `${project.wbsCode} updated.`);
    } catch (err) {
      setError(errMsg(err));
      setBusy(false);
    }
  };

  return (
    <Modal title={isNew ? "Add project" : `Edit ${project.wbsCode}`} onClose={onClose}>
      <form onSubmit={submit} noValidate className="space-y-4">
        <Field label="WBS code">
          <input className={inputCls} value={form.wbsCode} onChange={set("wbsCode")} disabled={!isNew} autoFocus={isNew} />
        </Field>
        <Field label="Project name">
          <input className={inputCls} value={form.projectName} onChange={set("projectName")} autoFocus={!isNew} />
        </Field>
        <div className="grid grid-cols-2 gap-4">
          <Field label="Expiry date">
            <input type="date" className={inputCls} value={form.expiryDate} onChange={set("expiryDate")} />
          </Field>
          <Field label="Amount allotted (₹)">
            <input type="number" min="0" step="0.01" className={inputCls} value={form.amountAllotted} onChange={set("amountAllotted")} />
          </Field>
        </div>
        {!isNew && (
          <p className="text-xs text-slate-500">
            Available budget is recalculated as allotted minus booked ({fmtMoney(project.amountBooked)} booked).
          </p>
        )}
        <Alert>{error}</Alert>
        <div className="flex justify-end gap-3">
          <Button type="button" variant="secondary" onClick={onClose}>Cancel</Button>
          <Button type="submit" disabled={busy}>{busy ? "Saving..." : isNew ? "Create project" : "Save changes"}</Button>
        </div>
      </form>
    </Modal>
  );
}
