import { createContext, useContext, useState } from "react";
import { api, AUTH_KEY } from "../api";

const AuthContext = createContext(null);

function readStored() {
  try {
    return JSON.parse(localStorage.getItem(AUTH_KEY) || "null");
  } catch {
    return null;
  }
}

export function AuthProvider({ children }) {
  const [auth, setAuth] = useState(readStored);

  const persist = (res) => {
    localStorage.setItem(AUTH_KEY, JSON.stringify(res));
    setAuth(res);
    return res.user;
  };

  const login = async (userId, password) => persist(await api.login({ userId, password }));
  const signup = async (form) => persist(await api.signup(form));
  const logout = () => {
    localStorage.removeItem(AUTH_KEY);
    setAuth(null);
  };

  return (
    <AuthContext.Provider value={{ user: auth?.user ?? null, login, signup, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
