// Flip VITE_USE_MOCK=false in .env once the Spring Boot backend is running.
export const USE_MOCK = import.meta.env.VITE_USE_MOCK !== "false";
export const API_URL = import.meta.env.VITE_API_URL || "http://localhost:8080";

// FR-3.1: "Base Rate is a system-defined constant or per-user configuration".
// Cost per man-hour, in rupees. The backend will own this value later.
export const BASE_RATE = 500;
