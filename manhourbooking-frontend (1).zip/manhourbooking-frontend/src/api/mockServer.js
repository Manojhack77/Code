// In-browser stand-in for the Spring Boot backend so the whole UI works today.
// Data lives in localStorage. It enforces the same rules as the spec:
//   cost = hours x BASE_RATE, hours per WBS = total hours x allocation %,
//   available = allotted - booked, allocation <= 100% per staff,
//   no booking/budget change on an expired project.
import { BASE_RATE } from "../config";

const KEY = "mhb_mock_db_v1";
const r2 = (n) => Math.round((Number(n) + Number.EPSILON) * 100) / 100;
const fail = (m) => {
  throw new Error(m);
};
const expired = (d) => {
  const t = new Date();
  t.setHours(0, 0, 0, 0);
  return new Date(`${d}T00:00:00`) < t;
};
const nextId = (list, key) => list.reduce((m, x) => Math.max(m, x[key]), 0) + 1;

function seed() {
  const d = {
    users: [
      { memberId: "ADMIN01", name: "Admin User", password: "admin123", role: "ADMIN" },
      { memberId: "ST1025", name: "Asha Rao", password: "staff123", role: "STAFF" },
      { memberId: "ST1026", name: "Ravi Kumar", password: "staff123", role: "STAFF" },
    ],
    projects: [
      { wbsCode: "WBS-1001", projectName: "Network Upgrade", expiryDate: "2027-03-31", amountAllotted: 1000000 },
      { wbsCode: "WBS-1002", projectName: "Mobile App", expiryDate: "2027-01-31", amountAllotted: 500000 },
      { wbsCode: "WBS-0900", projectName: "Legacy Migration", expiryDate: "2026-06-30", amountAllotted: 200000 },
    ].map((p) => ({ ...p, amountBooked: 0, amountAvailable: p.amountAllotted })),
    mappings: [
      { mappingId: 1, wbsCode: "WBS-1001", memberId: "ST1025", allocationPercentage: 60 },
      { mappingId: 2, wbsCode: "WBS-1002", memberId: "ST1025", allocationPercentage: 40 },
      { mappingId: 3, wbsCode: "WBS-1001", memberId: "ST1026", allocationPercentage: 100 },
    ],
    bookings: [],
  };
  // Sample history: Asha booked 160h in Aug 2026, Ravi 150h.
  const add = (memberId, month, year, total) => {
    d.mappings
      .filter((m) => m.memberId === memberId)
      .forEach((m) => {
        const hours = r2((total * m.allocationPercentage) / 100);
        const cost = r2(hours * BASE_RATE);
        const p = d.projects.find((x) => x.wbsCode === m.wbsCode);
        p.amountBooked = r2(p.amountBooked + cost);
        p.amountAvailable = r2(p.amountAllotted - p.amountBooked);
        d.bookings.push({
          bookingId: nextId(d.bookings, "bookingId"),
          wbsCode: m.wbsCode, memberId, hoursBooked: hours, month, year, calculatedCost: cost,
        });
      });
  };
  add("ST1025", 8, 2026, 160);
  add("ST1026", 8, 2026, 150);
  return d;
}

function load() {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) return JSON.parse(raw);
  } catch {
    /* fall through to seed */
  }
  const d = seed();
  localStorage.setItem(KEY, JSON.stringify(d));
  return d;
}

let db = load();
const save = () => localStorage.setItem(KEY, JSON.stringify(db));
const projectView = (p) => ({ ...p, status: expired(p.expiryDate) ? "Expired" : "Active" });
const userName = (id) => db.users.find((u) => u.memberId === id)?.name ?? id;
const project = (wbs) => db.projects.find((p) => p.wbsCode === wbs);

// Validates every change first, then applies them all (all-or-nothing, like @Transactional).
function applyDeltas(list) {
  const totals = {};
  list.forEach(({ wbs, delta }) => (totals[wbs] = r2((totals[wbs] || 0) + delta)));
  Object.entries(totals).forEach(([wbs, delta]) => {
    const p = project(wbs);
    if (!p) fail(`Project ${wbs} does not exist.`);
    if (delta !== 0 && expired(p.expiryDate))
      fail(`Project ${wbs} has expired. Bookings and budget updates are locked.`);
    if (delta > p.amountAvailable)
      fail(`Not enough budget in ${wbs}: needs ${delta.toFixed(2)} but only ${p.amountAvailable.toFixed(2)} is available.`);
  });
  Object.entries(totals).forEach(([wbs, delta]) => {
    const p = project(wbs);
    p.amountBooked = r2(p.amountBooked + delta);
    p.amountAvailable = r2(p.amountAllotted - p.amountBooked);
  });
}

const parseGroup = (id) => {
  const parts = String(id).split("_");
  const month = Number(parts.pop());
  const year = Number(parts.pop());
  return { memberId: parts.join("_"), month, year };
};

const impl = {
  // ---------- auth ----------
  login({ userId, password }) {
    const u = db.users.find(
      (x) => x.memberId.toLowerCase() === String(userId).trim().toLowerCase() && x.password === password,
    );
    if (!u) fail("Invalid user ID or password.");
    return { token: `mock.${u.memberId}`, user: { memberId: u.memberId, name: u.name, role: u.role } };
  },
  signup({ memberId, name, password }) {
    const id = String(memberId || "").trim();
    if (!id || !String(name || "").trim() || !password) fail("All fields are required.");
    if (password.length < 6) fail("Password must be at least 6 characters.");
    if (db.users.some((u) => u.memberId.toLowerCase() === id.toLowerCase()))
      fail("That staff ID is already registered.");
    db.users.push({ memberId: id, name: name.trim(), password, role: "STAFF" });
    save();
    return { token: `mock.${id}`, user: { memberId: id, name: name.trim(), role: "STAFF" } };
  },

  // ---------- staff ----------
  staffProjects(memberId) {
    return db.mappings
      .filter((m) => m.memberId === memberId)
      .map((m) => ({ ...projectView(project(m.wbsCode)), allocationPercentage: m.allocationPercentage }));
  },
  staffHistory(memberId) {
    const groups = {};
    db.bookings
      .filter((b) => b.memberId === memberId)
      .forEach((b) => {
        const id = `${memberId}_${b.year}_${b.month}`;
        groups[id] = groups[id] || { id, month: b.month, year: b.year, hours: 0 };
        groups[id].hours = r2(groups[id].hours + b.hoursBooked);
      });
    return Object.values(groups).sort((a, b) => b.year - a.year || b.month - a.month);
  },
  bookHours({ memberId, month, year, hours }) {
    const total = Number(hours);
    if (!(total > 0)) fail("Enter hours greater than zero.");
    if (total > 744) fail("Hours cannot exceed the number of hours in a month (744).");
    if (db.bookings.some((b) => b.memberId === memberId && b.month === month && b.year === year))
      fail("Hours for this month are already submitted. Use View to edit them.");
    const maps = db.mappings.filter((m) => m.memberId === memberId);
    if (!maps.length) fail("You are not assigned to any project yet. Please contact your administrator.");
    const rows = maps.map((m) => {
      const h = r2((total * m.allocationPercentage) / 100);
      return { wbsCode: m.wbsCode, hoursBooked: h, calculatedCost: r2(h * BASE_RATE) };
    });
    applyDeltas(rows.map((r) => ({ wbs: r.wbsCode, delta: r.calculatedCost })));
    rows.forEach((r) =>
      db.bookings.push({ bookingId: nextId(db.bookings, "bookingId"), memberId, month, year, ...r }),
    );
    save();
    return { message: "Hours submitted successfully!" };
  },
  updateHours({ id, hours }) {
    const total = Number(hours);
    if (!(total >= 0)) fail("Hours cannot be negative.");
    if (total > 744) fail("Hours cannot exceed 744 in a month.");

    // Admin edits one booking row; a staff member edits their whole month (split by allocation).
    if (!String(id).includes("_")) {
      const b = db.bookings.find((x) => x.bookingId === Number(id));
      if (!b) fail("Booking not found.");
      const cost = r2(total * BASE_RATE);
      applyDeltas([{ wbs: b.wbsCode, delta: r2(cost - b.calculatedCost) }]);
      b.hoursBooked = total;
      b.calculatedCost = cost;
      save();
      return { message: "Hours updated." };
    }
    const { memberId, month, year } = parseGroup(id);
    const rows = db.bookings.filter((b) => b.memberId === memberId && b.month === month && b.year === year);
    if (!rows.length) fail("Booking not found.");
    const old = rows.reduce((s, b) => s + b.hoursBooked, 0);
    const next = rows.map((b) => {
      const alloc = db.mappings.find((m) => m.memberId === memberId && m.wbsCode === b.wbsCode)?.allocationPercentage;
      const h = old > 0 ? r2((b.hoursBooked / old) * total) : r2((total * (alloc ?? 0)) / 100);
      return { b, h, cost: r2(h * BASE_RATE) };
    });
    applyDeltas(next.map((n) => ({ wbs: n.b.wbsCode, delta: r2(n.cost - n.b.calculatedCost) })));
    next.forEach((n) => {
      n.b.hoursBooked = n.h;
      n.b.calculatedCost = n.cost;
    });
    save();
    return { message: "Hours updated." };
  },

  // ---------- admin: dashboard ----------
  adminBookings({ month, year } = {}) {
    return db.bookings
      .filter((b) => (!month || b.month === Number(month)) && (!year || b.year === Number(year)))
      .map((b) => ({
        ...b,
        projectName: project(b.wbsCode)?.projectName ?? "",
        staffName: userName(b.memberId),
        projectExpired: project(b.wbsCode) ? expired(project(b.wbsCode).expiryDate) : false,
      }))
      .sort((a, b) => b.year - a.year || b.month - a.month || a.wbsCode.localeCompare(b.wbsCode));
  },

  // ---------- admin: projects ----------
  adminProjects() {
    return db.projects.map(projectView);
  },
  createProject({ wbsCode, projectName, expiryDate, amountAllotted }) {
    const code = String(wbsCode || "").trim().toUpperCase();
    const amt = r2(amountAllotted);
    if (!code || !String(projectName || "").trim() || !expiryDate) fail("WBS code, name and expiry date are required.");
    if (!(amt > 0)) fail("Amount allotted must be greater than zero.");
    if (project(code)) fail("A project with this WBS code already exists.");
    db.projects.push({
      wbsCode: code, projectName: projectName.trim(), expiryDate,
      amountAllotted: amt, amountBooked: 0, amountAvailable: amt,
    });
    save();
    return projectView(project(code));
  },
  updateProject(wbsCode, { projectName, expiryDate, amountAllotted }) {
    const p = project(wbsCode);
    if (!p) fail("Project not found.");
    const amt = r2(amountAllotted);
    if (!String(projectName || "").trim() || !expiryDate) fail("Project name and expiry date are required.");
    if (amt < p.amountBooked) fail(`Amount allotted cannot be below the amount already booked (${p.amountBooked}).`);
    p.projectName = projectName.trim();
    p.expiryDate = expiryDate;
    p.amountAllotted = amt;
    p.amountAvailable = r2(amt - p.amountBooked); // invariant: available = allotted - booked
    save();
    return projectView(p);
  },
  deleteProject(wbsCode) {
    if (db.bookings.some((b) => b.wbsCode === wbsCode))
      fail("This project has bookings and cannot be deleted.");
    db.projects = db.projects.filter((p) => p.wbsCode !== wbsCode);
    db.mappings = db.mappings.filter((m) => m.wbsCode !== wbsCode);
    save();
    return { message: "Project deleted." };
  },

  // ---------- admin: staff & mapping ----------
  adminStaff() {
    return db.users
      .filter((u) => u.role === "STAFF")
      .map((u) => ({
        memberId: u.memberId,
        name: u.name,
        totalAllocation: db.mappings.filter((m) => m.memberId === u.memberId).reduce((s, m) => s + m.allocationPercentage, 0),
      }));
  },
  adminMappings() {
    return db.mappings.map((m) => ({
      ...m,
      staffName: userName(m.memberId),
      projectName: project(m.wbsCode)?.projectName ?? "",
      projectExpired: project(m.wbsCode) ? expired(project(m.wbsCode).expiryDate) : false,
    }));
  },
  createMapping({ memberId, wbsCode, allocationPercentage }) {
    const pct = Number(allocationPercentage);
    if (!memberId || !wbsCode) fail("Choose a staff member and a project.");
    if (!(pct > 0 && pct <= 100)) fail("Allocation must be between 1 and 100.");
    if (!db.users.some((u) => u.memberId === memberId && u.role === "STAFF")) fail("Staff member not found.");
    const p = project(wbsCode);
    if (!p) fail("Project not found.");
    if (expired(p.expiryDate)) fail(`Project ${wbsCode} has expired and cannot take new assignments.`);
    if (db.mappings.some((m) => m.memberId === memberId && m.wbsCode === wbsCode))
      fail("This staff member is already mapped to that project.");
    const current = db.mappings.filter((m) => m.memberId === memberId).reduce((s, m) => s + m.allocationPercentage, 0);
    if (current + pct > 100)
      fail(`${userName(memberId)} is already at ${current}%. Adding ${pct}% would exceed 100%.`);
    db.mappings.push({ mappingId: nextId(db.mappings, "mappingId"), wbsCode, memberId, allocationPercentage: pct });
    save();
    return { message: "Mapping saved." };
  },
  deleteMapping(id) {
    db.mappings = db.mappings.filter((m) => m.mappingId !== Number(id));
    save();
    return { message: "Mapping removed." };
  },
  resetDemo() {
    localStorage.removeItem(KEY);
    db = load();
    return { message: "Demo data reset." };
  },
};

// Every call returns a promise with a short delay, like a real network request.
export const api = Object.fromEntries(
  Object.entries(impl).map(([name, fn]) => [
    name,
    async (...args) => {
      await new Promise((r) => setTimeout(r, 150));
      return structuredClone(fn(...args));
    },
  ]),
);
