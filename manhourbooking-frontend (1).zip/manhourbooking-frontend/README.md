# ManHourBooking frontend

React 19 + Vite + Tailwind 4 + react-router + axios.

```bash
npm install
npm run dev
```

By default the app runs against a built-in browser mock (`src/api/mockServer.js`), so every screen works without a backend.
Demo logins: `ADMIN01 / admin123` (admin), `ST1025 / staff123` (staff). Or sign up as a new staff member.

To use the real backend: copy `.env.example` to `.env`, set `VITE_USE_MOCK=false` and `VITE_API_URL`. Endpoints are listed in `API_CONTRACT.md`.

## Screens
- `/login`, `/signup`: authentication, redirects by role
- `/staff`: book hours for the current month, see assigned projects, history with View/Edit modal
- `/admin`: Dashboard (month/year filters, inline hour edit), Projects (CRUD, budget), Member mapping (allocation <= 100%)
