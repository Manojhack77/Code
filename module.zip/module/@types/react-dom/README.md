# Installation
> `npm install --save @types/react-dom`

# Summary
This package contains type definitions for react-dom (https://react.dev/).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/react-dom.

### Additional Details
 * Last updated: Wed, 09 Sep 2026 18:05:03 GMT
 * Dependencies: none
 * Peer dependencies: [@types/react](https://npmjs.com/package/@types/react)

# Credits
These definitions were written by [Asana](https://asana.com), [AssureSign](http://www.assuresign.com), [Microsoft](https://microsoft.com), [MartynasZilinskas](https://github.com/MartynasZilinskas), [Josh Rutherford](https://github.com/theruther4d), [Jessica Franco](https://github.com/Jessidhia), and [Sebastian Silbermann](https://github.com/eps1lon).
